console.log("page loaded...");

function play_video() {
    var run_video = document.querySelector('.video');
    run_video.play();
}

function pause_video() {
    var stop_video = document.querySelector('.video');
    stop_video.pause();
}